import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { RemovesalepostComponent } from './components/removesalepost/removesalepost.component';
import { PostforsaleComponent } from './components/postforsale/postforsale.component';

const routes: Routes = [
  { path: '', component: PostforsaleComponent },
  { path: 'home', component: PostforsaleComponent },
  { path: 'salepost', component: PostforsaleComponent },
  { path: 'removesalepost', component: RemovesalepostComponent },
  { path: '**', component: PostforsaleComponent }
];

export const routing: ModuleWithProviders<any> = RouterModule.forRoot(routes);
