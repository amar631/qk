export interface Item {
  itemId: number,
  emailId: string,
  itemName: string,
  description: string,
  price: number
}
