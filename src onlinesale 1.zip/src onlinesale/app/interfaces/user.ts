export interface User {
  emailId: string,
  userName: string,
  contactNo: number,
  location: string
}
