import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Item } from 'src/app/interfaces/item';
import { OnlinesaleappService } from 'src/app/services/onlinesaleapp.service';

@Component({
  selector: 'app-postforsale',
  templateUrl: './postforsale.component.html'
})
export class PostforsaleComponent implements OnInit{

  @ViewChild(NgForm) ngForm: NgForm;
  itemObj: Item;
  status: boolean;
  showDiv: boolean ;
  errorMsg: string;
  msg: string;
  itemId:number;

  //Do not modify signature
  constructor(private _saleService: OnlinesaleappService) {}

  //Do not modify signature
  ngOnInit() {
  }

  //Do not modify signature
  submitSalePostForm(form: NgForm) {
    //To do implement necessary logic
    this._saleService.postForSale(form.value.itemId).subscribe(
      response => {
        this.status = response;
        this.showDiv = false;
        if (this.status) {
          this.msg = "Post for sale is successful";
        }
        else {
          this.msg = "Some error occurred";
        }
      },
      error => {
        this.errorMsg = error;
      },
      () => console.log("Post method executed successfully")
    );

  }
}




