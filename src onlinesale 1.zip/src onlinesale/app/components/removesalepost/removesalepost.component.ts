import { Component } from '@angular/core';
import { Item } from 'src/app/interfaces/item';
import { OnlinesaleappService } from 'src/app/services/onlinesaleapp.service';

@Component({
  selector: 'app-removesalepost',
  templateUrl: './removesalepost.component.html'

})
export class RemovesalepostComponent {

  saleItemDetails: Item[];
  showMsgDiv: boolean ;
  errMsg: string;
  status: boolean;
  msg: string;

  //Do not modify signature
  constructor(private _saleService: OnlinesaleappService) { }

  //Do not modify signature
  ngOnInit() {
    //To do implement necessary logic
    this.getSaleItemDetails();
    if(this.saleItemDetails == null)
    this.showMsgDiv = true;

  }

  //Do not modify signature
  getSaleItemDetails() {
    //To do implement necessary logic
    this._saleService.getSaleItemDetails().subscribe(
      response => {
        this.saleItemDetails = response;

        this.showMsgDiv = false;

      },
      error => {
        this.saleItemDetails = null;
        this.errMsg = error;

      },
      () => console.log("Get sale item details displayed successfully")
    );

  }

  //Do not modify signature
  deletePost(itemObj: Item) {
    //To do implement necessary logic
    this._saleService.removeSalePost(itemObj.itemId).subscribe(
      response => {
        this.status = response;
        if (this.status) {
          this.msg = "Deleted successfully";
          this.ngOnInit()

        }
        else {
          this.msg = "Some error occurred";
        }
      },
      error => {
        this.errMsg = error;
      },
      () => console.log("Remove method executed successfully")
    );
  }
}
