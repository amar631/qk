import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { Item } from '../interfaces/item';

@Injectable({
  providedIn: 'root'
})
export class OnlinesaleappService {
    //Do not modify signature
  constructor(private http:HttpClient) { }

  //Do not modify signature
  getSaleItemDetails():Observable<Item[]>{
    //To do implement necessary logic here
    return this.http.get<Item[]>('http://localhost:7144/api/OnlineSale/GetItemsForSale').pipe(catchError(this.errorHandler));
  
  }

  //Do not modify signature
  postForSale(itemObj: Item): Observable<boolean> {
    //To do implement necessary logic here
    var itemObj: Item = {
      itemId: 0,
      emailId:"emailId",
      itemName: "itemName",
      description: "description",
      price:0
    }
    return this.http.post<boolean>('http://localhost:7144/api/OnlineSale/SalePostForItems', itemObj).pipe(catchError(this.errorHandler));
  }

  //Do not modify signature
  removeSalePost(itemId: number): Observable<boolean> {
    //To do implement necessary logic here
    
    itemId =itemId
    //let httpOptions = { headers: new HttpHeaders ({ 'Content-Type': 'application/json' }), body: itemId };




    return this.http.delete<boolean>('http://localhost:7144/api/OnlineSale/RemoveSalePost?itemId='+itemId).pipe(catchError(this.errorHandler));
  }

  //Do not modify signature
  errorHandler(error: HttpErrorResponse) {
    //To do implement necessary logic here
    console.error(error);
    return throwError(error.message || "server error");
    
  }
}

