﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OnlineFoodOrderDALCrossPlatform
{
    public class CommonRepository
    {
        OnlineFoodOrderDBContext context;
        public CommonRepository()
        {
            context = new OnlineFoodOrderDBContext();
            // To-do: Implement necessary code here
        }

        #region CheckDeliveryStatus
        public int CheckDeliveryStatus(int orderId)
        {
            var deliverystatus = 0;
            try
            {
                deliverystatus = (from s in context.Orders select OnlineFoodOrderDBContext.ufn_CheckDeliveryStatus(orderId))
                      .FirstOrDefault();
                
            }
            catch (Exception)
            {
                deliverystatus = -99;
                throw;
            }
            // To-do: Implement necessary code here
            return deliverystatus;
        }
        #endregion

        #region DeleteOrderDetails
        public bool DeleteOrderDetails(int orderId)
        {
            // To-do: Implement necessary code here
            return false;
        }
        #endregion

        #region GetAllOrderDetails
        public List<OrderDetails> GetAllOrderDetails(int orderId)
        {
            List<OrderDetails> listorderdetails = null;
            try
            {
               SqlParameter prmOrderId = new SqlParameter("@OrderId", orderId);
                listorderdetails = context.orderdetails.FromSqlRaw("SELECT * FROM ufn_GetOrderDetails(@OrderId)",
                                                              prmOrderId).ToList();
            }
            catch (Exception)
            {
                listorderdetails = null;
               // throw;
            }
           
            // To-do: Implement necessary code here
            return listorderdetails;
        }
        #endregion
    }
}
