﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OnlineFoodOrderDALCrossPlatform
{
    public class AdminRepository
    {
        OnlineFoodOrderDBContext context;
        public AdminRepository()
        {
            context = new OnlineFoodOrderDBContext();
            // To-do: Implement necessary code here
        }

        #region AddItem
        public bool AddItem(string itemId, string itemName, int categoryId, decimal price)
        {
            bool status = false;
            Item i = new Item();
            try
            {
                i.ItemId = itemId;
                i.ItemName = itemName;
                i.CategoryId = categoryId;
                i.Price = price;

                context.Items.Add(i);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
               // throw;
            }
            // To-do: Implement necessary code here
            return status;
        }
        #endregion   

        #region GetAllCategoryOrderDetails
        public List<CategoryItemDetails> GetAllCategoryOrderDetails(int categoryId)
        {
            List<CategoryItemDetails> itemdetail = null;
            try
            {
                SqlParameter prmCategoryId = new SqlParameter("@categoryId", categoryId);
                itemdetail=context.categoryItemDetail.FromSqlRaw("SELECT * FROM ufn_GetAllOrderDetails(@categoryId)", prmCategoryId).ToList();
                
            }
            catch (Exception)
            {
                itemdetail = null;
                throw;
            }
            // To-do: Implement necessary code here
            return itemdetail;
        }
        #endregion

        #region UpdatePrice
       
        public bool UpdatePrice(string itemId, decimal itemPrice)
        {
            var status = false;
            try
            {
                Item i = context.Items.Find(itemId);
                i.Price = itemPrice;
                status = true;
                context.SaveChanges();
            }
            catch (Exception)
            {
                status = false;
              //  throw;
            }
            // To-do: Implement necessary code here
            return status;
        }
        #endregion

    }
}
