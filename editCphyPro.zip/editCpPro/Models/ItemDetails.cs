﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace OnlineFoodOrderDALCrossPlatform.Models
{
    public class ItemDetails
    {
        // To-do: Implement appropriate properties
    }
}
