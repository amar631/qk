﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OnlineFoodOrderDALCrossPlatform
{
    public class CustomerRepository
    {
        OnlineFoodOrderDBContext context;
        public CustomerRepository()
        {
            context = new OnlineFoodOrderDBContext();
            // To-do: Implement necessary code here
        }

        #region GetAllItems
        public List<Item> GetAllItems()
        {
            // To-do: Implement necessary code here
            return null;
        }
        #endregion

        #region GetItemDetails
        public List<ItemDetails> GetItemDetails(string categoryName)
        {
            // To-do: Implement necessary code here
            return null;
        }
        #endregion

        #region GetItemPrice
        public decimal GetItemPrice(string itemId)
        {
            // To-do: Implement necessary code here
            return 0;
        }
        #endregion

        #region PlaceOrder
        public int PlaceOrder(int customerId, string itemId, int quantity, 
            string deliveryAddress, DateTime orderDate, out decimal totalPrice, 
            out int orderId)
        {

            int returnResult = 0;
            totalPrice = 0;
            int r = 0;
            orderId = -1;
            // To-do: Implement necessary code here
            if (itemId != null && quantity != 0)
            {
                SqlParameter prmCustomerId = new SqlParameter("@CustomerId", customerId);
                SqlParameter prmItemId = new SqlParameter("@ItemId", itemId);
                SqlParameter prmQuantity = new SqlParameter("@Quantity", quantity);
                SqlParameter prmDeliveryAddress = new SqlParameter("@DeliveryAddress", deliveryAddress);
                SqlParameter prmOrderDate = new SqlParameter("@OrderDate", orderDate);

                SqlParameter prmTotalPrice = new SqlParameter("@TotalPrice", System.Data.SqlDbType.Decimal);
                prmTotalPrice.Direction = System.Data.ParameterDirection.Output;

                SqlParameter prmOrderId = new SqlParameter("@OrderId", System.Data.SqlDbType.Int);
                prmOrderId.Direction = System.Data.ParameterDirection.Output;

                SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
                prmReturnResult.Direction = System.Data.ParameterDirection.Output;


                try
                {
                    r = context.Database.ExecuteSqlRaw("EXEC @ReturnResult = usp_AddOrderDetails @CustomerId, @ItemId, @Quantity, @DeliveryAddress, @OrderDate, @TotalPrice OUT, @OrderId OUT",
                        prmReturnResult, prmCustomerId, prmItemId, prmQuantity, prmDeliveryAddress, prmOrderDate, prmTotalPrice, prmOrderId);

                    returnResult = Convert.ToInt32(prmReturnResult.Value);
                    
                        
                        totalPrice = Convert.ToDecimal(prmTotalPrice.Value);
                        orderId = Convert.ToInt32(prmOrderId.Value);
                    
                    //return returnResult;
                }
                catch (Exception)
                {
                    
                    totalPrice = 0;
                    orderId = 0;
                    returnResult = -99;
                    throw;
                }
                return returnResult;
            }
            else
            {
                return returnResult;
            }

        }  
        #endregion
    }
}
