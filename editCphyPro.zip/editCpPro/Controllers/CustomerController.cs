﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineFoodOrderDALCrossPlatform;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineFoodOrderWebService.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CustomerController : Controller
    {
        CustomerRepository repository;
        public CustomerController()
        {
            repository = new CustomerRepository();
            // To-do: Implement necessary code here
        }

        #region GetAllItems
        public JsonResult GetAllItems()
        {
            // To-do: Implement necessary code here
            return null;
        }
        #endregion

        #region GetAllItemsByCategoryName
        public JsonResult GetAllItemsByCategoryName(string categoryName)
        {
            // To-do: Implement necessary code here
            return null;
        }
        #endregion

        #region GetItemPrice
        public JsonResult GetItemPrice(string itemId)
        {
            // To-do: Implement necessary code here
            return null;
        }
        #endregion

        #region PlaceOrder
        [HttpPost]
        public JsonResult PlaceOrder(Models.Order order)
        {

            int customerid = order.CustomerId;
            string itemid = order.ItemId;
            int quantity = order.Quantity;
            string deliveryaddress = order.DeliveryAddress;
            DateTime orderdate = order.OrderDate;
            decimal totalprice = order.TotalPrice;
            int orderid = order.OrderId;

            int status = 0;
            string message = "";
            try
            {
                status=repository.PlaceOrder(customerid, itemid, quantity, deliveryaddress, orderdate, out totalprice,out orderid );
                if (status == 1)
                    message = "Order Placed successfully. Your order id = " + orderid + " and total price to be paid = "+ totalprice;
            }
            catch (Exception)
            {
                status = -99;
                message = "unsccessful";
              //  throw;
            }
            return Json(message);
            // To-do: Implement necessary code here
            
        } 

        #endregion
    }
}
