﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineFoodOrderDALCrossPlatform;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineFoodOrderWebService.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CommonController : Controller
    {
        CommonRepository repository;
        public CommonController()
        {
            repository = new CommonRepository();
            // To-do: Implement necessary code here
        }

        #region CheckDeliveryStatus
        public JsonResult CheckDeliveryStatus(int orderId)
        {
            int status = 0;
            var message = "";
            try
            {
               status= repository.CheckDeliveryStatus(orderId);
                if (status == 1)
                    message="Not Delivered!";
                else if (status == 0)
                    message="Delivered!";
            }
            catch (Exception)
            {
                message = "Error!";
              //  throw;
            }
            // To-do: Implement necessary code here
            return Json(message);
        }
        #endregion

        #region DeleteOrderDetails
        public JsonResult DeleteOrderDetails(int orderId)
        {
            // To-do: Implement necessary code here
            return null;
        }
        #endregion

        #region GetAllOrderDetails
        [HttpGet]
        public JsonResult GetAllOrderDetails(int orderId)
        {
            List<OrderDetails> listorderdetails = null;
            try
            {
                listorderdetails= repository.GetAllOrderDetails(orderId);
            }
            catch (Exception)
            {
                listorderdetails = null;
               // throw;
            }
            // To-do: Implement necessary code here
            return Json(listorderdetails);
        }
        #endregion
    }
}
