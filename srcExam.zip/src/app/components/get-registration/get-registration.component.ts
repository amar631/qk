import { Component, OnInit } from '@angular/core';
import { IRegistrationDetails } from '../../interfaces/RegistrationDetails';
import { RegistrationService } from '../../services/registration.service';


@Component({
  selector: 'app-get-registration',
  templateUrl: './get-registration.component.html'
})
export class GetRegistrationComponent implements OnInit{
  registrationDetails: IRegistrationDetails[];
  message: string;
  errorMsg: string;
  showMsgDiv: boolean;
  status: boolean;

  constructor(private registrationservice: RegistrationService) { }

  ngOnInit() {
    //To do: Implement necessary logic
    this.getRegistrations();
    if (this.registrationDetails == null) {
      this.showMsgDiv = true;
    }
  }

  getRegistrations() {
    //To do: Implement necessary logic
    this.registrationservice.getRegistrations().subscribe(
      resSuccess => {
        this.registrationDetails = resSuccess;
        this.showMsgDiv = false;
      },
      resError => {
        this.registrationDetails = null;
        this.errorMsg = resError;
      },
      ()=> console.log("Get registrations completed")
    )
  }

  removeRegistration(regObj: IRegistrationDetails) {
    //To do: Implement necessary logic
    this.registrationservice.removeRegistrations(regObj).subscribe(
      resSuccess => {
        this.status = resSuccess;
        if (resSuccess) {
          alert("Deleted");
          this.ngOnInit();
        }
        else {
          alert("Unsuccessful");
        }
      },
      resError => {
        this.errorMsg = resError;
        alert("Error");

      },
      () => console.log("Remove executed Successfully")

    );
  }
}
