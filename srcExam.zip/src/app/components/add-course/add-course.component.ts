import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RegistrationService } from '../../services/registration.service';


@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html'
})
export class AddCourseComponent implements OnInit{
  @ViewChild(NgForm) ngForm: NgForm;
  message: boolean;
  errorMsg: string;
  showMsgDiv: boolean;
  status: boolean;

  constructor(private registrationservice: RegistrationService) { }

  ngOnInit() {
  }

  addCourse(courseId: string, courseName: string, duration: number, rating: number, enrolledCount: number) {
    //To do: Implement necessary logic
    this.registrationservice.addCourse(courseId, courseName, duration, rating, enrolledCount).subscribe(
      resSuccess => {
        this.message = resSuccess;
        if (resSuccess) {
          alert("Added");
        }
        else {
          alert("Unsuccessfull");
        }

      },
      resError => {
        this.errorMsg = resError;
        alert("Error");

      },
      () => console.log("Add Executed Successfully")
    );
  }

}
