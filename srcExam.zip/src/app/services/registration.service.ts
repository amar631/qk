import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { ICourseDetails } from '../interfaces/CourseDetails';
import { IRegistrationDetails } from '../interfaces/RegistrationDetails';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private _http: HttpClient) { }

  //Do not modify the signature
  getRegistrations(): Observable<IRegistrationDetails[]> {
    //To do: Implement necessary logic and change the return statement
    return this._http.get<IRegistrationDetails[]>('https://localhost:44380/api/Registration/GetRegistrationDetails').pipe(catchError(this.errorHandler));
  }

  //Do not modify the signature
  addCourse(courseId: string, courseName: string, duration: number, rating: number, enrolledCount: number): Observable<boolean> {
    //To do: Implement necessary logic and change the return statement
    var regObj: ICourseDetails = { courseId: courseId, courseName: courseName, duration: duration, rating: rating, enrolledCount: enrolledCount }
    return this._http.post<boolean>('https://localhost:44380/api/Registration/AddCourse', regObj).pipe(catchError(this.errorHandler));
  }

  //Do not modify the signature
  removeRegistrations(regObj: IRegistrationDetails) {
    //To do: Implement necessary logic and change the return statement
    let httpsOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
      body: regObj
    };

    return this._http.delete<boolean>('https://localhost:44380/api/Registration/RemoveRegistrationDetails', httpsOptions).pipe(catchError(this.errorHandler));
  }


  errorHandler(error: HttpErrorResponse) {
    //To do: Implement necessary logic
    console.error(error);
    return throwError(error.message || "Server Error");
    }

}
