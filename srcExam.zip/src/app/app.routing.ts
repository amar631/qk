import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { AddCourseComponent } from './Components/add-course/add-course.component';
import { GetRegistrationComponent } from './Components/get-registration/get-registration.component';


const routes: Routes = [
  { path: ' ', component: GetRegistrationComponent },
  { path: 'viewRegistration', component: GetRegistrationComponent },
  { path: 'addCourse', component: AddCourseComponent },
  { path: '**', component: GetRegistrationComponent }
];

export const appRoutingProviders: any[] = [];
export const routing: ModuleWithProviders<any> = RouterModule.forRoot(routes);

