export * from './Components/add-course/add-course.component';
export * from './Components/get-registration/get-registration.component';
