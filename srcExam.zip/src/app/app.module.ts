import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AddCourseComponent } from './Components/add-course/add-course.component';
import { RegistrationService } from './services/registration.service';
import {  HttpClientModule } from '@angular/common/http';
import { GetRegistrationComponent } from './Components/get-registration/get-registration.component';
import { routing } from './app.routing';
import { HttpClientTestingModule } from '@angular/common/http/testing';



@NgModule({
  declarations: [
    AppComponent,
    AddCourseComponent,
    AddCourseComponent,
    GetRegistrationComponent,
 
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    routing,
  ],
  providers: [RegistrationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
