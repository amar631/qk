export interface IRegistrationDetails {
  registrationId: string;
  userId: string;
  courseId: string;
  registrationDate: Date;
}
