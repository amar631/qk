export interface IUserDetails {
  userId: string;
  userName: string;
  emailId: string;
  contactNumber: number;
}
