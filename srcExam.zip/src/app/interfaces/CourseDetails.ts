export interface ICourseDetails {
  courseId: string;
  courseName: string;
  duration: number;
  rating: number;
  enrolledCount:number;
}
