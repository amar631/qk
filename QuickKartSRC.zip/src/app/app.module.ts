import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

/*import { AppRoutingModule } from './app-routing.module';*/
import { AppComponent } from './app.component';
import { ViewProductsComponent } from './Component/view-products/view-products.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './Component/login/login.component';
import { RegisterComponent } from './Component/register/register.component';
import { CommonLayoutComponent } from './Component/common-layout/common-layout.component';
import { HomeComponent } from './Component/home/home.component';
import { routing } from './app.routing';
import { CustomerLayoutComponent } from './Component/customer-layout/customer-layout.component';
import { ViewCartComponent } from './Component/view-cart/view-cart.component';
import { FeedbackComponent } from './Component/feedback/feedback.component';
import { ViewPurchaseComponent } from './Component/view-purchase/view-purchase.component';
import { ReviewComponent } from './Component/review/review.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewProductsComponent,
    LoginComponent,
    RegisterComponent,
    CommonLayoutComponent,
    CustomerLayoutComponent,
    ViewCartComponent,
    FeedbackComponent,
    HomeComponent,
    ViewPurchaseComponent,
    ReviewComponent
  ],
  imports: [
    BrowserModule,
   /* AppRoutingModule,*/
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
