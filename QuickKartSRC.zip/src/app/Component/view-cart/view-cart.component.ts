import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ICartProduct } from '../../interface/cartProduct';
import { UserService } from '../../service/user.service';


@Component({
  selector: 'app-viewcart',
  templateUrl: './view-cart.component.html',
  styleUrls: ['./view-cart.component.css']
})
export class ViewCartComponent implements OnInit {
  errorMsg: string="";
  emailId: string="";
  Products: ICartProduct[]=[];
  showError: boolean = false;
  status: boolean = false;
  imageSrc: string="";

  constructor(private _userService: UserService, private router: Router) { }

  ngOnInit() {
    this.emailId = <string>sessionStorage.getItem('userName');

    if (this.emailId == null) {
      this.router.navigate(['/login']);
    }
    this._userService.getCartProducts(this.emailId)
      .subscribe(
        responseCartProductData => {
          this.Products = responseCartProductData;
          if (this.Products.length == 0) {
            this.showError = true;
            this.errorMsg = "Your cart is empty.";
          }
        },
        responseCartProductError => {
          this.Products = [];
          this.errorMsg = responseCartProductError;
          console.log(this.errorMsg);
          if (this.Products.length == 0) {
            this.showError = true;
            this.errorMsg = "No records found.";
          }
        },
        () => console.log("GetCartProducts method executed successfully")
      );

  }


}
