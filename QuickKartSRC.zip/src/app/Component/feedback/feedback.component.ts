import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  msg: string = "";
  feedbackForm: FormGroup;
  
  constructor(private formBuilder: FormBuilder) {

  }

  ngOnInit() {
    this.feedbackForm = this.formBuilder.group({
      emailId: ['', [Validators.required, Validators.minLength(12)]],
      name: ['', [Validators.required]],
      feedback: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(100)]]
    });
  }

  SubmitForm(form: FormGroup) {
    if (this.feedbackForm.valid) {
      this.msg = "Feedback given successfully"
    }
    else {
      this.msg = "Try again Later"
    }
    
  }

}

