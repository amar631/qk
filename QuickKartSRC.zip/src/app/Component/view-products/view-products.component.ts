import { Component, OnInit } from '@angular/core';
import { IProduct } from '../../interface/product';
import { ICategory } from '../../interface/category';
import { ProductService } from '../../service/product.service';
import { Router } from '@angular/router';
import { UserService } from '../../service/user.service';

@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.css']
})
export class ViewProductsComponent implements OnInit {
  products: IProduct[] = [];
  categories: ICategory[] = [];
  filteredProducts: IProduct[] = [];
  searchByProductName: string = "";
  searchByCategoryId: string ="0";
  imgSrc: string = "";
  showMsgDiv: boolean = false;
  errMsg: string = "";
  userRole: string = "";
  userName: string = "";
  customerLayout: boolean = false;
  commonLayout: boolean = false;
    message: boolean;
  constructor(private _productService: ProductService, private _userService: UserService, private router: Router) {
    this.userRole = <string>sessionStorage.getItem('userRole');
    this.userName = <string>sessionStorage.getItem('userName');
    if (this.userRole == "Customer") {
      this.customerLayout = true;
    }
    else {
      this.commonLayout = true;
    }
  }
  ngOnInit() {
    this.getProducts();

    if (this.products == null || !this.products.length) {
      this.showMsgDiv = true;

    }
    this.filteredProducts = this.products;
    this.imgSrc = "assets/quickKart-images/add-item.jpg";
  }
  getProducts() {
    this._productService.getProducts().subscribe(
      responseProductData => {
        this.products = responseProductData;
        this.filteredProducts = responseProductData;
        this.showMsgDiv = false;
        this.getProductCategories();
      },
      responseProductError => {
        this.products = [];
        this.errMsg = responseProductError;
        console.log(this.errMsg);
      },
      () => console.log("GetProducts method excuted successfully")
    );
  }
  getProductCategories() {
    this._productService.getProductCategories().subscribe(
      responseCategoryData => this.categories = responseCategoryData,
      responseCategoryError => {
        this.categories = [];
        this.errMsg = responseCategoryError;
        console.log(this.errMsg);
      },
      () => console.log("GetProductCategoies method excuted successfully")
    );
  }
  searchProduct(productName: string) {
    if (this.searchByCategoryId == "0") {
      this.filteredProducts = this.products;
    }
    else {
      this.filteredProducts = this.products?.filter(prod => prod.categoryId.toString() == this.searchByCategoryId);
    }
    if (productName != null || productName == "") {
      this.searchByProductName = productName;
      this.filteredProducts = this.filteredProducts?.filter(prod => prod.productName.toLowerCase().indexOf(productName.toLowerCase()) >= 0);
    }
    if (this.filteredProducts?.length == 0) {
      this.showMsgDiv = true;
    }
    else {
      this.showMsgDiv = false;
    }
  }
  searchProductByCategory(categoryId: string) {
    if (this.searchByProductName != null || this.searchByProductName == "") {
      this.filteredProducts = this.products?.filter(prod => prod.productName.toLowerCase().indexOf(this.searchByProductName!.toLowerCase()) >= 0);
    }
    else {
      this.filteredProducts = this.products;
    }
    this.searchByCategoryId = categoryId;
    if (this.searchByCategoryId == "0") {
      this.filteredProducts = this.products;
    }
    else {
      this.filteredProducts = this.filteredProducts?.filter(prod => prod.categoryId.toString() == this.searchByCategoryId);
    }
  }

  addToCart(prod: IProduct) {
    if (this.userRole == null) {
      this.router.navigate(['/login']);
    }
    else {
      this._userService.addProductToCart(prod.productId, <string>this.userName)
        .subscribe(
          responseProductData => {
            
            if (responseProductData) {
              console.log(responseProductData);
              alert("Product added sucessfully.")
            }
          },
          responseProductError => {
            this.errMsg = responseProductError,
              console.log(this.errMsg),
              alert("Sorry, something went wrong. Please try again after sometime.")
          },
          () => console.log("AddToCart method executed successfully")
        );
    }
  }
}
