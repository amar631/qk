import { Component, OnInit } from '@angular/core';
import { PurchaseService } from '../../service/purchase.service';
import { IPuchaseDetails } from '../../interface/PurchaseDetails';

@Component({
  selector: 'app-view-purchase',
  templateUrl: './view-purchase.component.html',
  styleUrls: ['./view-purchase.component.css']
})
export class ViewPurchaseComponent implements OnInit{

  purchases: IPuchaseDetails[] = [];
  email: string = "";
  showMsgDiv: boolean = false;
  errMsg: string = "";

  constructor(private _purchaseservice: PurchaseService) {

    this.email = <string>sessionStorage.getItem('userName');
  }

  ngOnInit() {

    if (this.purchases == null || !this.purchases.length) {
      this.showMsgDiv = true;
    }


      this._purchaseservice.getPurchaseDetails(this.email).subscribe(
        responseProductData => {
          this.purchases = responseProductData;
          this.showMsgDiv = false;
        },
        responseProductError => {
          this.purchases = [];
          this.errMsg = responseProductError;
          console.log(this.errMsg);
        },
        () => console.log("GetPurchaseDetails method excuted successfully")
      );
    }

}
