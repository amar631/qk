import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IUser } from '../interface/user';
import { Observable, catchError, throwError } from 'rxjs';
import { ICart } from '../interface/cart';
import { ICartProduct } from '../interface/cartProduct';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private _http: HttpClient) { }

  validateCredentials(id: string, password: string): Observable<string> {

    var userObj: IUser = { emailId: id, userPassword: password, gender: "", roleId: 0, dateOfBirth: new Date(), address: "" };
    return this._http.post<string>('https://localhost:44366/api/user/ValidateUserCredentials', userObj).pipe(catchError(this.errorHandler));
  }

  addProductToCart(productId: string, emailId: string): Observable<boolean> {

    var cartObj: ICart = { productId: productId, emailId: emailId, quantity: 1 };
    return this._http.post<boolean>('https://localhost:44366/api/user/AddProductToCart', cartObj).pipe(catchError(this.errorHandler));
  }

  getCartProducts(emailId: string): Observable<ICartProduct[]> {
    let param = "?emailId=" + emailId;
    return this._http.get<ICartProduct[]>('https://localhost:44366/api/user/GetCartProducts' + param).pipe(catchError(this.errorHandler));
  }


  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  }
}
