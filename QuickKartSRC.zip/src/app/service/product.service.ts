import { Injectable } from '@angular/core';
import { IProduct } from '../interface/product';
import { ICategory } from '../interface/category';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  products: IProduct[] = [];
  categories: ICategory[] = [];
  constructor(private _httpclient: HttpClient) { }

  getProducts(): Observable<IProduct[]> {
    let tempVar = this._httpclient.get<IProduct[]>('https://localhost:44366/api/product/getproducts').pipe(catchError(this.errorHandler));;
    return tempVar;
  }
  getProductCategories(): Observable<ICategory[]> {
    let tempVar = this._httpclient.get<ICategory[]>('https://localhost:44366/api/Category/getCategories').pipe(catchError(this.errorHandler));;
    return tempVar;
  }
  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  }
}
