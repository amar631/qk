import { HttpClient, HttpErrorResponse} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IReview } from '../interface/review';
import { Observable } from 'rxjs/internal/Observable';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReviewService {

  constructor(private _http: HttpClient) { }

  viewRating(emailId: string): Observable<IReview[]> {
    let param = "?emailId=" + emailId;
    return this._http.get<IReview[]>('https://localhost:44366/api/rating/DisplayAllReviewDetailsByEmailId' + param).pipe(catchError(this.errorHandler));
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  }
}
