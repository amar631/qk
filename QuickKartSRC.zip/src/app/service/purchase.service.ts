import { Injectable } from '@angular/core';
import { IPuchaseDetails } from '../interface/PurchaseDetails';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PurchaseService {

    constructor(private _http: HttpClient) { }

    getPurchaseDetails(emailId: string): Observable<IPuchaseDetails[]> {
        let param = "?emailId=" + emailId;
        return this._http.get<IPuchaseDetails[]>('https://localhost:44366/api/purchase/GetPurchaseDetailsByEmailId' + param).pipe(catchError(this.errorHandler));
    }


    errorHandler(error: HttpErrorResponse) {
        console.error(error);
        return throwError(error.message || "Server Error");
    }
}
