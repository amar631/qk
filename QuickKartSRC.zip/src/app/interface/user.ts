export interface IUser {
  emailId: string,
  userPassword: string,
  roleId: number,
  gender: string,
  dateOfBirth: Date,
  address: string
}
