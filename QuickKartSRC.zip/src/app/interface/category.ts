export interface ICategory {
  categoryId: number;
  categoryName: string
}
