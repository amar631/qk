export interface IReview
{
  emailId: string,
  productId: string,
  productName: string,
  reviewRating: number,
  reviewComments:string
}
 
