export interface IProduct {
  productId: string;
  productName: string;
  price: number;
  quantityAvailable: number;
  categoryId: number;

}
