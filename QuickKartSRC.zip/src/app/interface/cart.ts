export interface ICart {
  productId: string,
  emailId: string,
  quantity: number
}
