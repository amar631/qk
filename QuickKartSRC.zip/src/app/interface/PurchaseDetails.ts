export interface IPuchaseDetails {
  purchaseId: number,
  emailId: string,
  productId: string,
  quantityPurchased: number,
  dateOfPurchase: Date;
}

   
