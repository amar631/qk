import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { HomeComponent } from './Component/home/home.component';
import { LoginComponent } from './Component/login/login.component';
import { ViewProductsComponent } from './Component/view-products/view-products.component';
import { AuthGuardService } from './service/auth-guard.service';
import { ViewCartComponent } from './Component/view-cart/view-cart.component';
import { ViewPurchaseComponent } from './Component/view-purchase/view-purchase.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'viewProducts', component: ViewProductsComponent, canActivate: [AuthGuardService] },
  { path: 'viewCart', component: ViewCartComponent },
  { path: 'viewPurchase', component: ViewPurchaseComponent },
  { path: '**', component: HomeComponent }
];
export const routing: ModuleWithProviders<RouterModule> = RouterModule.forRoot(routes);
