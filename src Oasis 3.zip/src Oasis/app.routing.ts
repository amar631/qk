import { ModuleWithProviders } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { GetBookingDetailsComponent } from "./app/components/get-booking-details/get-booking-details.component";
import { AddTableComponent } from "./app/components/add-table/add-table.component";

const routes: Routes=[
  { path: '', component: GetBookingDetailsComponent },
  { path: 'viewBooking', component: GetBookingDetailsComponent },
  { path: 'addTable', component: AddTableComponent },
];

export const routing : ModuleWithProviders<any> = RouterModule.forRoot(routes);
