import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { IBookingDetail } from '../interfaces/booking-details';
import { ITableDetails } from '../interfaces/table-details';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  constructor(private _http: HttpClient) {}

  getBookingDetails(): Observable<IBookingDetail[]>{
    //To Do : implement necessary logic here
    return this._http.get<IBookingDetail[]>('https://localhost:7238/api/Restaurant/GetBookingDetails').pipe(catchError(this.errorHandler));
    }

  addTableDetails(tableId: string, type: string, accommodation: number, tableInchargeId: string): Observable<boolean> {
    //To Do : implement necessary logic here
    var tableObj: ITableDetails = {
      tableId:tableId,
      type: type,
      accommodation: accommodation,
      tableInchargeId: tableInchargeId
      
    }
    return this._http.post<boolean>('https://localhost:7238/api/Restaurant/InsertTable', tableObj).pipe(catchError(this.errorHandler));
  }

  removeBooking(bookingId: number/*, customerName: string, bookingdate: Date, contact: number, tableNumber: string, duration: number, totalSeats: number*/):Observable<boolean>{
    //To Do : implement necessary logic here
    //var bObj: IBookingDetail = {
    //  bookingId: bookingId,
    //  customerName: customerName,
    //  bookingdate: bookingdate,

    //}
    //let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: bookingId };
    return this._http.delete<boolean>('https://localhost:7238/api/Restaurant/DeleteBooking?bookingId=' +bookingId).pipe(catchError(this.errorHandler));
  }

  errorHandler(error: HttpErrorResponse) {
    //To Do : implement necessary logic here
    console.error(error);

    return throwError(error.message ||"server error");
    }
  }
