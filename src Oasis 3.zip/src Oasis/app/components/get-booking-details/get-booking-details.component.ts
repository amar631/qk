
import { Component, OnInit } from '@angular/core';
import { IBookingDetail } from 'src/app/interfaces/booking-details';
import { RestaurantService } from 'src/app/services/restaurant.service';

@Component({
  selector: 'app-get-booking-details',
  templateUrl: './get-booking-details.component.html',
  styleUrls: ['./get-booking-details.component.css']
})
export class GetBookingDetailsComponent implements OnInit{
bookingDetails : IBookingDetail[];
message:string;
errorMsg:string;
showMsgDiv:boolean;
status:boolean;

constructor(private restaurantservice: RestaurantService) { }

ngOnInit() {
  //To Do : implement necessary logic here
  this.getBooking();
  if (this.bookingDetails == null)
  this.showMsgDiv = true;
  }

getBooking() {
  //To Do : implement necessary logic here
  this.restaurantservice.getBookingDetails().subscribe(
    response => {
      this.bookingDetails = response;
      this.showMsgDiv = false;
    },
    error => {
      this.bookingDetails = null;
      this.errorMsg = error;
    },
    () => console.log("Bookings Available")


  );
}
deleteBooking(bookingId:number,customerName:string,bookingDate:Date,contact:number,tableNumber:string,duration:number,totalSeats:number){
  //To Do : implement necessary logic here

  this.restaurantservice.removeBooking(bookingId).subscribe(
    response => {
      this.status = response;
      if (this.status) {
        alert("Booking deleted successfully");
        this.ngOnInit()
      }
      else {
        alert("Booking could not be deleted");
      }

    },
    error => {
      this.errorMsg = error;
      alert("Something went wrong");

    },
    () => console.log("Delete method executed successfully")

  );
 }
}
