import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ITableDetails } from 'src/app/interfaces/table-details';
import { RestaurantService } from 'src/app/services/restaurant.service';

@Component({
  selector: 'app-add-table',
  templateUrl: './add-table.component.html',
  styleUrls: ['./add-table.component.css']
})
export class AddTableComponent {
  @ViewChild(NgForm) ngForm: NgForm;
  message: boolean;
  tableDetails: ITableDetails
  errorMsg: string;
  showMsgDiv: boolean;
  status: boolean;
  constructor(private restaurantservice: RestaurantService) { }

  ngOnInit() {}
  
  addTable(tableId: string, type: string, accommodation: number, tableInchargeId: string) {
    //To Do : implement necessary logic here
    this.restaurantservice.addTableDetails(tableId, type, accommodation, tableInchargeId).subscribe(
      response => {
        this.message = response;
        if (this.message) {
          alert("Successfully Added");
        }
        else {
          alert("Sorry, something went wrong");
        }
      },
      error => {
        this.errorMsg = error;
        alert("Something went wrong");
      },
      () => console.log("Add Successfully Executed")
    );
  }
}
