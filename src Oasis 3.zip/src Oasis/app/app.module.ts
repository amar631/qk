import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { GetBookingDetailsComponent } from './components/get-booking-details/get-booking-details.component';
import { AddTableComponent } from './components/add-table/add-table.component';
import { HttpClientModule } from '@angular/common/http';
import { routing } from 'src/app.routing';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    GetBookingDetailsComponent,
    AddTableComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
