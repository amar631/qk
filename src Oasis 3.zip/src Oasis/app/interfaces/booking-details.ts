export interface IBookingDetail {
bookingId:number;
bookingDate:Date;
duration:number;
contact:number;
customerName:string;
tableNumber:string;
totalSeats:number;
}
