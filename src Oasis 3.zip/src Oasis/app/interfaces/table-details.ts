export interface ITableDetails {
tableId:string;
type:string;
accommodation:number;
tableInchargeId:string;
}
