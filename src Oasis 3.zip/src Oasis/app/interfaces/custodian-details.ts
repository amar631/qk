export interface ICustodianDetails {
  custodianName: string;
  custodianId: string;
  experience: number;
  feedbackcount: number;
}
